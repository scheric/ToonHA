=======
Credits
=======

Development Lead
----------------

* Paul de Nooijer <paul@sesha.net>

Contributors
------------

* Costas Tyfoxylos <costas.tyf@gmail.com>

* Lem Severein <boltgolt@gmail.com>
