.. :changelog:

History
-------

0.1 (13-04-2017)
----------------

* Initial release


0.2 (25-04-2017)
----------------

* Changed to toonlib library


0.3 (25-04-2017)
----------------

* Added support smartplugs


0.4 (26-04-2017)
----------------

* Added support for solar panels connected to Toon


0.5 (01-05-2017)
----------------

* Added support for smoke detectors


0.6 (08-05-2017)
----------------

* Upgraded to toonlib 1.0.0 with improved API connectivity